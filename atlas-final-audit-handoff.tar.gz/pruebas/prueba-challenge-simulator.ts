import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { evaluateChallenge } from '../src/trading-lab/challenge-simulator.ts';
import { createTestFixturePropFirm, type Program, type RuleSet } from '../src/trading-lab/prop-firm.ts';
import { ejecutarBacktest } from '../src/trading-lab/backtest.ts';
import { loadAndMapCSV, EURUSD_H1_BASELINE_CONFIG } from '../src/trading-lab/historical-baseline.ts';
import type { SerieHistorica, EstrategiaCruceMedias, ConfiguracionBacktest, ResultadoBacktest } from '../src/trading-lab/tipos.ts';

function getBaselineBacktest(): ResultadoBacktest {
  const velas = loadAndMapCSV(EURUSD_H1_BASELINE_CONFIG.csvPath);
  const serie: SerieHistorica = {
    id: 'EURUSD_H1_TEST',
    simbolo: 'EURUSD',
    intervalo: 'H1',
    origen: 'DUKASCOPY_BID_UTC',
    velas,
  };
  const estrategia: EstrategiaCruceMedias = {
    tipo: 'cruce_medias',
    id: 'MA_CROSS_BASELINE',
    version: 1,
    mediaRapida: 9,
    mediaLenta: 21,
    riesgoPorOperacion: 0.01,
  };
  const config: ConfiguracionBacktest = {
    capitalInicial: 10000,
    comisionPorcentaje: 0.0001,
    spreadPorcentaje: 0.0001,
    slippagePorcentaje: 0.00005,
    maxRiesgoPorOperacion: 0.01,
    semilla: 42,
  };
  return ejecutarBacktest(serie, estrategia, config);
}

describe('TASK 14: Prop Firm Challenge Simulator', () => {
  const firm = createTestFixturePropFirm();
  const program = firm.programs[0];

  it('evaluates baseline against test fixture program', () => {
    const bt = getBaselineBacktest();
    const eval_ = evaluateChallenge(bt, program, 'FOREX_SPOT', 'EURUSD');

    assert.ok(['PASS', 'FAIL', 'INCOMPLETE'].includes(eval_.result));
    assert.equal(eval_.programId, program.programId);
    assert.equal(eval_.ruleSetVersion, 1);
    assert.equal(eval_.sourceStatus, 'TEST_FIXTURE');
    assert.ok(typeof eval_.metrics.returnPct === 'number');
    assert.ok(typeof eval_.metrics.maxDrawdownPct === 'number');
    assert.ok(typeof eval_.metrics.tradingDays === 'number');
    assert.ok(eval_.metrics.tradeCount > 0);
    assert.equal(eval_.metrics.dailyLossBasis, 'REALIZED_PNL');
    assert.ok(eval_.accountNormalization.scaleFactor > 0);
    assert.ok(Array.isArray(eval_.dataLimitations));
  });

  it('baseline fails profit target (negative return)', () => {
    const bt = getBaselineBacktest();
    const eval_ = evaluateChallenge(bt, program, 'FOREX_SPOT', 'EURUSD');

    assert.ok(['FAIL', 'INCOMPLETE'].includes(eval_.result));
    assert.ok(eval_.failureReasons.includes('PROFIT_TARGET_NOT_REACHED'));
  });

  it('reports MAX_DRAWDOWN_BREACH when drawdown exceeds limit', () => {
    const bt = getBaselineBacktest();
    const eval_ = evaluateChallenge(bt, program, 'FOREX_SPOT', 'EURUSD');

    if (bt.metricas.drawdownMaximo > program.ruleSet.rules.maxLossLimitPct) {
      assert.ok(eval_.failureReasons.includes('MAX_DRAWDOWN_BREACH'));
    }
  });

  it('detects INCOMPATIBLE_MARKET', () => {
    const bt = getBaselineBacktest();
    const eval_ = evaluateChallenge(bt, program, 'FUTURES', 'ES');

    assert.equal(eval_.result, 'INCOMPATIBLE');
    assert.ok(eval_.failureReasons.includes('INCOMPATIBLE_MARKET'));
  });

  it('detects NOT_VERIFIED rules', () => {
    const bt = getBaselineBacktest();
    const unverifiedProgram: Program = {
      ...program,
      ruleSet: { ...program.ruleSet, sourceStatus: 'NOT_VERIFIED' },
    };
    const eval_ = evaluateChallenge(bt, unverifiedProgram, 'FOREX_SPOT', 'EURUSD');

    assert.equal(eval_.result, 'NOT_VERIFIED');
    assert.ok(eval_.failureReasons.includes('RULE_NOT_VERIFIED'));
  });

  it('detects INSTRUMENT_NOT_ALLOWED', () => {
    const bt = getBaselineBacktest();
    const restrictedProgram: Program = {
      ...program,
      ruleSet: {
        ...program.ruleSet,
        rules: { ...program.ruleSet.rules, allowedInstruments: ['GBPUSD'] },
      },
    };
    const eval_ = evaluateChallenge(bt, restrictedProgram, 'FOREX_SPOT', 'EURUSD');

    assert.ok(eval_.failureReasons.includes('INSTRUMENT_NOT_ALLOWED'));
  });

  it('failure reasons are specific and enumerated', () => {
    const bt = getBaselineBacktest();
    const eval_ = evaluateChallenge(bt, program, 'FOREX_SPOT', 'EURUSD');

    const validReasons = [
      'DAILY_LOSS_BREACH', 'MAX_DRAWDOWN_BREACH', 'PROFIT_TARGET_NOT_REACHED',
      'MIN_DAYS_NOT_MET', 'MAX_DAYS_EXCEEDED', 'CONSISTENCY_RULE_BREACH',
      'INSTRUMENT_NOT_ALLOWED', 'INCOMPATIBLE_MARKET', 'RULE_NOT_VERIFIED',
      'BACKTEST_REJECTED', 'DAILY_LOSS_DATA_INSUFFICIENT',
      'TRAILING_DRAWDOWN_DATA_INSUFFICIENT', 'POSITION_LIMIT_DATA_INSUFFICIENT',
      'NEWS_RULE_DATA_INSUFFICIENT',
    ];
    for (const reason of eval_.failureReasons) {
      assert.ok(validReasons.includes(reason), `Unknown failure reason: ${reason}`);
    }
  });

  it('metrics include all required fields', () => {
    const bt = getBaselineBacktest();
    const eval_ = evaluateChallenge(bt, program, 'FOREX_SPOT', 'EURUSD');

    const m = eval_.metrics;
    assert.ok(typeof m.returnPct === 'number');
    assert.ok(typeof m.maxDrawdownPct === 'number');
    assert.ok(typeof m.dailyMaxLossPct === 'number');
    assert.ok(typeof m.tradingDays === 'number');
    assert.ok(typeof m.tradeCount === 'number');
    assert.ok(m.winRate === null || typeof m.winRate === 'number');
    assert.ok(m.profitFactor === null || typeof m.profitFactor === 'number');
    assert.ok(typeof m.maxDayProfitPct === 'number');
    assert.ok(m.consistencyOk === null || typeof m.consistencyOk === 'boolean');
  });

  it('no real trading in module', () => {
    const src = readFileSync('src/trading-lab/challenge-simulator.ts', 'utf-8');
    assert.ok(!src.includes('fetch('), 'No fetch calls');
    assert.ok(!src.includes('MT5'), 'No MT5 references');
    assert.ok(!src.includes('real_order'), 'No real order references');
  });

  it('no fake company rules', () => {
    const src = readFileSync('src/trading-lab/challenge-simulator.ts', 'utf-8').toLowerCase();
    for (const name of ['ftmo', 'topstep', 'apex', 'fundingpips']) {
      assert.ok(!src.includes(name), `Must not reference ${name}`);
    }
  });
});
