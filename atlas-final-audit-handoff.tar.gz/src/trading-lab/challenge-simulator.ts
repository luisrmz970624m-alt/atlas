/** Prop Firm Challenge Simulator — TASK 14.
 * Consumes existing backtest results + RuleSet. NO new TradingEngine. NO real trading. */

import type { ResultadoBacktest, OperacionBacktest } from './tipos.ts';
import type { Program, MarketType } from './prop-firm.ts';
import { checkMarketCompatibility } from './prop-firm.ts';

export type ChallengeResult = 'PASS' | 'FAIL' | 'INCOMPLETE' | 'NOT_VERIFIED' | 'INCOMPATIBLE';

export type FailureReason =
  | 'DAILY_LOSS_BREACH'
  | 'MAX_DRAWDOWN_BREACH'
  | 'PROFIT_TARGET_NOT_REACHED'
  | 'MIN_DAYS_NOT_MET'
  | 'MAX_DAYS_EXCEEDED'
  | 'CONSISTENCY_RULE_BREACH'
  | 'INSTRUMENT_NOT_ALLOWED'
  | 'INCOMPATIBLE_MARKET'
  | 'RULE_NOT_VERIFIED'
  | 'BACKTEST_REJECTED'
  | 'DAILY_LOSS_DATA_INSUFFICIENT'
  | 'TRAILING_DRAWDOWN_DATA_INSUFFICIENT'
  | 'POSITION_LIMIT_DATA_INSUFFICIENT'
  | 'NEWS_RULE_DATA_INSUFFICIENT';

export interface ChallengeEvaluation {
  result: ChallengeResult;
  failureReasons: FailureReason[];
  metrics: {
    returnPct: number;
    maxDrawdownPct: number;
    dailyMaxLossPct: number;
    dailyLossBasis: 'REALIZED_PNL';
    tradingDays: number;
    tradeCount: number;
    winRate: number | null;
    profitFactor: number | null;
    maxDayProfitPct: number;
    consistencyOk: boolean | null;
  };
  accountNormalization: {
    backtestCapital: number;
    programAccountSize: number;
    scaleFactor: number;
  };
  drawdownType: 'STATIC' | 'TRAILING';
  dataLimitations: string[];
  programId: string;
  ruleSetVersion: number;
  sourceStatus: string;
}

export function evaluateChallenge(
  backtest: ResultadoBacktest,
  program: Program,
  datasetMarketType: MarketType,
  datasetInstrument: string,
): ChallengeEvaluation {
  const rules = program.ruleSet.rules;
  const failureReasons: FailureReason[] = [];
  const dataLimitations: string[] = [];

  const backtestCapital = backtest.metricas.capitalInicial ?? 10000;
  const scaleFactor = program.accountSize / backtestCapital;
  const accountNormalization = { backtestCapital, programAccountSize: program.accountSize, scaleFactor };

  const baseMetrics = {
    returnPct: backtest.metricas.retornoNeto,
    maxDrawdownPct: backtest.metricas.drawdownMaximo,
    dailyMaxLossPct: 0,
    dailyLossBasis: 'REALIZED_PNL' as const,
    tradingDays: 0,
    tradeCount: backtest.metricas.operaciones,
    winRate: null as number | null,
    profitFactor: backtest.metricas.profitFactor,
    maxDayProfitPct: 0,
    consistencyOk: null as boolean | null,
  };

  const baseResult = (result: ChallengeResult) => ({
    result,
    failureReasons,
    metrics: baseMetrics,
    accountNormalization,
    drawdownType: rules.drawdownType,
    dataLimitations,
    programId: program.programId,
    ruleSetVersion: program.ruleSet.version,
    sourceStatus: program.ruleSet.sourceStatus,
  });

  // Market compatibility check
  const compat = checkMarketCompatibility(datasetMarketType, program);
  if (!compat.compatible) {
    failureReasons.push('INCOMPATIBLE_MARKET');
    return baseResult('INCOMPATIBLE');
  }

  // Instrument check
  if (rules.allowedInstruments && !rules.allowedInstruments.includes(datasetInstrument)) {
    failureReasons.push('INSTRUMENT_NOT_ALLOWED');
  }

  // Source verification
  if (program.ruleSet.sourceStatus === 'NOT_VERIFIED') {
    failureReasons.push('RULE_NOT_VERIFIED');
    return baseResult('NOT_VERIFIED');
  }

  // Backtest rejected
  if (!backtest.aprobado) {
    failureReasons.push('BACKTEST_REJECTED');
    return baseResult('FAIL');
  }

  // Compute daily PnL from trades (realized only)
  const dailyPnl = computeDailyPnl(backtest.operaciones);
  const tradingDays = Object.keys(dailyPnl).length;

  dataLimitations.push('Daily loss uses realized PnL only, not intraday equity');

  // Daily max loss — normalized to account size
  let dailyMaxLossPct = 0;
  let maxDayProfitPct = 0;
  for (const [, pnl] of Object.entries(dailyPnl)) {
    const normalizedPnl = pnl * scaleFactor;
    const pct = (normalizedPnl / program.accountSize) * 100;
    if (pct < 0) dailyMaxLossPct = Math.max(dailyMaxLossPct, Math.abs(pct));
    if (pct > 0) maxDayProfitPct = Math.max(maxDayProfitPct, pct);
  }

  if (tradingDays === 0) {
    failureReasons.push('DAILY_LOSS_DATA_INSUFFICIENT');
    dataLimitations.push('No trading days computed from backtest operations');
  }

  // Win rate
  const wins = backtest.operaciones.filter(o => o.pnlNeto >= 0).length;
  const winRate = backtest.metricas.operaciones > 0 ? (wins / backtest.metricas.operaciones) * 100 : null;

  // Consistency check
  let consistencyOk: boolean | null = null;
  if (rules.consistencyRulePct !== null && tradingDays > 0) {
    const totalProfit = Object.values(dailyPnl).filter(v => v > 0).reduce((a, b) => a + b, 0);
    if (totalProfit > 0) {
      const maxProfitDay = Math.max(...Object.values(dailyPnl));
      consistencyOk = (maxProfitDay / totalProfit) * 100 <= rules.consistencyRulePct;
    } else {
      consistencyOk = true;
    }
  }

  // Trailing drawdown check
  if (rules.drawdownType === 'TRAILING') {
    dataLimitations.push('Trailing drawdown requires tick-level equity curve; using static drawdownMaximo as approximation');
    failureReasons.push('TRAILING_DRAWDOWN_DATA_INSUFFICIENT');
  }

  // Position limit
  if (rules.positionLimit !== null) {
    dataLimitations.push('Position limit enforcement requires per-bar position tracking not available in backtest');
    failureReasons.push('POSITION_LIMIT_DATA_INSUFFICIENT');
  }

  // News restriction
  if (rules.newsRestricted === true) {
    dataLimitations.push('News restriction enforcement requires economic calendar data not available');
    failureReasons.push('NEWS_RULE_DATA_INSUFFICIENT');
  }

  const metrics = {
    returnPct: backtest.metricas.retornoNeto,
    maxDrawdownPct: backtest.metricas.drawdownMaximo,
    dailyMaxLossPct,
    dailyLossBasis: 'REALIZED_PNL' as const,
    tradingDays,
    tradeCount: backtest.metricas.operaciones,
    winRate,
    profitFactor: backtest.metricas.profitFactor,
    maxDayProfitPct,
    consistencyOk,
  };

  // Rule checks
  if (dailyMaxLossPct > rules.dailyLossLimitPct) {
    failureReasons.push('DAILY_LOSS_BREACH');
  }

  if (backtest.metricas.drawdownMaximo > rules.maxLossLimitPct) {
    failureReasons.push('MAX_DRAWDOWN_BREACH');
  }

  if (backtest.metricas.retornoNeto < rules.profitTargetPct) {
    failureReasons.push('PROFIT_TARGET_NOT_REACHED');
  }

  if (tradingDays < rules.minTradingDays) {
    failureReasons.push('MIN_DAYS_NOT_MET');
  }

  if (rules.maxTradingDays !== null && tradingDays > rules.maxTradingDays) {
    failureReasons.push('MAX_DAYS_EXCEEDED');
  }

  if (consistencyOk === false) {
    failureReasons.push('CONSISTENCY_RULE_BREACH');
  }

  // Determine result — INCOMPLETE when data limitations prevent evaluation
  const hasDataInsufficiency = failureReasons.some(r => r.endsWith('_DATA_INSUFFICIENT'));
  const hasHardFailure = failureReasons.some(r =>
    ['DAILY_LOSS_BREACH', 'MAX_DRAWDOWN_BREACH', 'PROFIT_TARGET_NOT_REACHED',
     'MIN_DAYS_NOT_MET', 'MAX_DAYS_EXCEEDED', 'CONSISTENCY_RULE_BREACH',
     'INSTRUMENT_NOT_ALLOWED'].includes(r));

  let result: ChallengeResult;
  if (hasHardFailure) result = 'FAIL';
  else if (hasDataInsufficiency) result = 'INCOMPLETE';
  else result = 'PASS';

  return {
    result,
    failureReasons,
    metrics,
    accountNormalization,
    drawdownType: rules.drawdownType,
    dataLimitations,
    programId: program.programId,
    ruleSetVersion: program.ruleSet.version,
    sourceStatus: program.ruleSet.sourceStatus,
  };
}

function computeDailyPnl(operations: OperacionBacktest[]): Record<string, number> {
  const daily: Record<string, number> = {};
  for (const op of operations) {
    const day = op.salida.slice(0, 10);
    daily[day] = (daily[day] ?? 0) + op.pnlNeto;
  }
  return daily;
}
