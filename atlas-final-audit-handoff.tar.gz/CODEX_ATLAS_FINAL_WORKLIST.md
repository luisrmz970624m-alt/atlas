# CODEX Atlas — worklist final

## Baseline canónico

> **Estado más reciente (2026-09-27):** TASK 6B = **BLOCKED** por el permiso
> de loopback del entorno. Esta anotación supersede cualquier frase posterior
> que describa una revalidación local autorizada de TASK 6.

| Etapa | Resultado | Clasificación |
|---|---:|---|
| `RESTRICTED_SANDBOX_AUDIT` | 51/69; 18 fallos por `EPERM`/`EROFS`/`SQLITE_CANTOPEN` | HISTORICAL FACT |
| `LOCAL_STABLE_BASELINE_PRE_COGNITIVE` | 844/844 | HISTORICAL FACT |
| `COGNITIVE_API_INITIAL` | 846/846 | HISTORICAL FACT |
| TASK 1 Entities | 847/847 | GREEN / VERIFIED |
| TASK 2 Experiment Refs | 848/848 | GREEN / VERIFIED |
| TASK 3 Experiment Traceability | 850/850 | GREEN / VERIFIED |
| TASK 4 Context Budget | 851/851 | GREEN / VERIFIED |
| TASK 5 Negative Security | 853/853 | GREEN / VERIFIED; CURRENT BASELINE |

## Cerrado con evidencia histórica y vigente

| Fase | Estado | Evidencia |
|---|---|---|
| 0–1 baseline e infraestructura | VERIFIED | Suite local autorizada 844/844; sandbox restringido documentado. |
| 2 integridad | PARTIAL | Árbol clasificado; no se mezcló ni eliminó trabajo preexistente. |
| 3 identidad de dataset | VERIFIED | ID canónico `EURUSD_H1_DUKASCOPY_2021-2026`; SHA-256 y 35,651 filas confirmados. |
| 4 proveedores | VERIFIED | Ollama/Claude/ChatGPT conservan sus gates; Gemini figura `unavailable`, sin proveedor falso. |
| 5–6 persistencia y SQLite | VERIFIED | Inyección/rutas temporales existentes, validadas en suite local. |
| 7 panel activo/legacy | PARTIAL | `panel-vortice` es servido; `src/panel/` queda como legado no servido y no se borra. |
| 8 conocimiento/memoria | PARTIAL | API cognitiva GET/read-only existe; UI cognitiva sigue pendiente. |
| 9 agentes/video/simulación | VERIFIED | Agentes y video permanecen `UNAVAILABLE`; simulación es `SIMULATED`. |
| 10 Trading Lab | VERIFIED | Motor existente, MA_CROSS, OOS, walk-forward, paper y MT5 demo read-only pasan pruebas. |
| 11 visual Vórtice | VERIFIED | Captura directa en runtime, núcleo, seis módulos y estados honestos visibles. |
| 12 cobertura/dead code | PARTIAL | No hay cobertura de líneas configurada sin instalar paquetes; no se borró código candidato. |
| 13–14 runtime y final | VERIFIED | HTTP histórico 200/404 y CURRENT BASELINE 853/853. |
| 15 visualización | VERIFIED_INLINE | Capturas reales incluidas en la entrega; la API de captura disponible no expone escritura a `artifacts/`. |

## Tasks cognitivas

| Área | Estado | Evidencia |
|---|---|---|
| TASK 1 Entities | GREEN / VERIFIED | entidades normalizadas, deduplicadas y acotadas |
| TASK 2 Experiment Refs | GREEN / VERIFIED | referencias de experimento en DTOs cognitivos |
| TASK 3 Experiment Traceability | GREEN / VERIFIED | trazabilidad de experimentos preservada |
| TASK 4 Context Budget | GREEN / VERIFIED | semántica en caracteres; `NOT_COMPUTED` cuando no hay texto cargado |
| TASK 5 Negative Security | GREEN / VERIFIED | límites, controles, IDs y percent-encoding hostil endurecidos |
| TASK 6B Revalidate TASK 6 Gate | BLOCKED | 2026-09-27: `ATLAS_SIN_RED=true npm run prueba` reprodujo 51/70 y las pruebas cognitivas HTTP aisladas 3 pass / 2 fail por `listen EPERM: operation not permitted 127.0.0.1`. No se modificó producto para enmascararlo. |

## Estado de tareas posteriores (actualizado 2026-09-27)

1. TASK 6B — **GREEN / VERIFIED** (853/853, resuelto con evidencia local autorizada).
2. TASK 7 Cognitive API Contract Review — **GREEN / VERIFIED**.
3. TASK 8 Cognitive UI Read-only — **GREEN / VERIFIED**.
4. TASK 9 Vórtice Cognitive Connection — **GREEN / VERIFIED**.
5. TASK 10 TradingReasoning + Cognitive Retrieval — **GREEN / VERIFIED** (858/858).
6. TASK 11 Historical Baseline 3B.4 — **GREEN** (868/868) → **Hardened 11.1** (12/12).
7. TASK 12 OOS/Walk-forward/Robustness — **GREEN** (877/877) → **Hardened 12.1** (12/12).
8. TASK 13 Prop Firm Lab Foundation — **GREEN** (891/891) → **Hardened 13.1** (18/18).
9. TASK 14 Prop Firm Challenge Simulator — **GREEN** (901/901) → **Hardened 14.1** (10/10).
10. TASK 15 Final Multilayer Review — **GREEN** → **Hardened 15.1**.

## Pendiente restante

- Consolidar o retirar `src/panel/` solo tras una revisión humana.
- Backend de agentes/video sigue UNAVAILABLE.
- PNG persistentes: **NOT_VERIFIED**.
- Cobertura de líneas: pendiente de autorizar herramienta.
- Trailing drawdown: requiere datos tick-level (DATA_INSUFFICIENT).
- Position limit / news restriction: requiere datos adicionales (DATA_INSUFFICIENT).

## Actualización autorizada — 2026-09-27

- TASK 6B / TASK 6: **GREEN / VERIFIED** con 853/853; 51/69 es auditoría histórica de sandbox.
- TASK 7: **GREEN / VERIFIED**; procedencia de memoria limitada a fuente declarada.
- TASK 8: **GREEN / VERIFIED**; nueva vista local `#cognitivo` verificada en runtime.
- TASK 9: **GREEN / VERIFIED**; conexión no monolítica panel/API cognitiva.
- TASK 10: **GREEN / VERIFIED** con 858/858 (resuelto en sesión posterior).
- Suite posterior TASK 10: **858/858 pass**, 0 fail, 0 skip; `git diff --check` PASS.

## Actualización — TASK 11 a TASK 15 (2026-09-27)

| Task | Estado | Suite |
|------|--------|-------|
| TASK 11 Historical Baseline 3B.4 | GREEN | 868/868 |
| TASK 12 OOS/Walk-Forward/Robustness | GREEN | 877/877 |
| TASK 13 Prop Firm Lab Foundation | GREEN | 891/891 |
| TASK 14 Prop Firm Challenge Simulator | GREEN | 901/901 |
| TASK 15 Final Multilayer Review | GREEN | 901/901 |

## Hardening Round — TASK 11.1 a TASK 15.1 (2026-09-27)

| Task | Estado | Targeted |
|------|--------|----------|
| TASK 11.1 Historical Baseline Hardening | GREEN | 12/12 |
| TASK 12.1 OOS/WF Hardening | GREEN | 12/12 |
| TASK 13.1 Prop Firm Hardening | GREEN | 18/18 |
| TASK 14.1 Challenge Simulator Hardening | GREEN | 10/10 |
| TASK 15.1 Report Reconciliation | GREEN | N/A |

Total targeted hardening: **52/52 PASS**. No commit, no push, no staging.
